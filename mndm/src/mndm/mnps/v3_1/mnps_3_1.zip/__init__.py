"""Experimental MNPS v3.1 candidate measurements.

This namespace is additive. It does not replace the canonical MNPS
``[m, d, e]`` chart, the existing 9D coordinates, or their Jacobians.
Candidate measurements remain exploratory until the owning analysis work
ratifies their estimands, support, reliability, and redundancy gates.
"""

from .candidates import (
    E1_CANDIDATE_ID,
    E1_METHOD_VERSION,
    MNPS31Candidate,
    MNPS31E1Measurement,
    MNPS31E1WindowSupport,
    MNPS31WindowSupport,
    MNPS31_CANDIDATES,
    compute_e1_channel_median_permutation_entropy,
)
from .eeg_metrics import (
    EEGCandidateMeasurement,
    compute_d1_sensor_weighted_global_efficiency,
    compute_d2_sensor_pairclass_difference,
    compute_d3_sensor_rdm_dispersion,
    compute_e2_sensor_lz78_phrase_density,
    compute_e3_sensor_participation_ratio,
    compute_m1_sensor_phase_variability,
    compute_m3_sensor_activity_reconfiguration,
    compute_m3_sensor_connectivity_reconfiguration,
)
from .eeg_windows import (
    AUDIT_SCHEMA as EEG_WINDOW_AUDIT_SCHEMA,
    AuditedEEGWindow,
    load_audited_edf_eeg_window,
)

__all__ = [
    "E1_CANDIDATE_ID",
    "E1_METHOD_VERSION",
    "MNPS31Candidate",
    "MNPS31E1Measurement",
    "MNPS31E1WindowSupport",
    "MNPS31WindowSupport",
    "MNPS31_CANDIDATES",
    "compute_e1_channel_median_permutation_entropy",
    "EEGCandidateMeasurement",
    "compute_m1_sensor_phase_variability",
    "compute_m3_sensor_activity_reconfiguration",
    "compute_m3_sensor_connectivity_reconfiguration",
    "compute_d1_sensor_weighted_global_efficiency",
    "compute_d2_sensor_pairclass_difference",
    "compute_d3_sensor_rdm_dispersion",
    "compute_e2_sensor_lz78_phrase_density",
    "compute_e3_sensor_participation_ratio",
    "EEG_WINDOW_AUDIT_SCHEMA",
    "AuditedEEGWindow",
    "load_audited_edf_eeg_window",
]
